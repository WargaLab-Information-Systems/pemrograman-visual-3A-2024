-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Waktu pembuatan: 12 Nov 2024 pada 16.39
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perusahaan_modul5`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `jabatan` varchar(30) DEFAULT NULL,
  `departemen` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`id`, `nama`, `jabatan`, `departemen`) VALUES
(1, 'Andi Hutagaol', 'Akuntan', 'IT'),
(2, 'pak hunting-ting', 'Manager', 'HR'),
(3, 'Cici', 'Pemasaran', 'HR'),
(4, 'RAFI', 'Manager', 'IT'),
(5, 'pak hunting', 'Supervisor', 'Finance'),
(6, 'RAPI', 'Manager', 'Marketing'),
(7, 'Mas Rapi', 'Manager', 'HR'),
(8, 'Mas Amba', 'Akuntan', 'IT'),
(9, 'Ar\'raffi Abqori Nur Azizi', 'Pengembang', 'IT'),
(10, 'Citra Dewi', 'Pemasaran', 'Marketing'),
(11, 'Dedi Suryanto', 'Pemasaran', 'Finance'),
(12, 'Joko Purwanto', 'Supervisor', 'Operations'),
(13, 'Krisna Yulianto', 'Pemasaran', 'Operations'),
(14, 'Putu Kurniawan', 'Pengembang', 'IT'),
(15, 'Rudi Hartanto', 'Pemasaran', 'Finance'),
(16, 'Xander Setiawan', 'Pengembang', 'Finance'),
(17, 'mas jual kepala', 'Akuntan', 'Marketing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `proyek`
--

CREATE TABLE `proyek` (
  `id` int(11) NOT NULL,
  `nama_proyek` varchar(50) DEFAULT NULL,
  `durasi_pengerjaan` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `proyek`
--

INSERT INTO `proyek` (`id`, `nama_proyek`, `durasi_pengerjaan`) VALUES
(1, 'Pengembangan Produk Baru', '10 minggu'),
(2, 'Renovasi Hotel', '4 minggu'),
(3, 'Penyusunan Kebijakan Baru', '10 minggu'),
(5, 'Cukur Gratis', '8 minggu'),
(6, 'Riset Pasar Digital', '2 minggu'),
(7, 'Kecupan Gratis', '1 minggu'),
(8, 'Pembangunan Jembatan', '3 minggu'),
(9, 'Implementasi ERP', '4 minggu'),
(10, 'pengembangan Sistem Informasi', '2 minggu'),
(11, 'Revitalisaisi Taman Kota', '2 minggu'),
(12, 'Pelatihan Karyawan', '5 minggu'),
(13, 'Re-Branding Perusahaan', '8 minggu'),
(14, 'Audit Keuangan Internal', '9 minggu'),
(15, 'Pembangunan Jalan Raya', '10 minggu'),
(16, 'Proyek Renovasi Hotel', '11 minggu'),
(17, 'Pengembangan Infrastruktur IT', '12 minggu'),
(18, 'Penyusunan Laporan Tahunan', '14 minggu'),
(19, 'Desain Website E-commerce', '16 minggu'),
(20, 'Proyek Renovasi Hotel', '90 minggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_karyawan` int(11) NOT NULL,
  `id_proyek` int(11) NOT NULL,
  `peran` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_karyawan`, `id_proyek`, `peran`) VALUES
(1, 1, 'Developer'),
(1, 2, 'Developer'),
(2, 5, 'Developer'),
(7, 1, 'Staff IT'),
(8, 1, 'HRD');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `proyek`
--
ALTER TABLE `proyek`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_karyawan`,`id_proyek`),
  ADD KEY `id_proyek` (`id_proyek`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `proyek`
--
ALTER TABLE `proyek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_proyek`) REFERENCES `proyek` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
